import React from 'react';
import { DCCRecord } from '../types';
import { calculateGujaratiTotals, calculateDRMSlip } from '../utils/defaultData';
import { formatIndianInteger } from '../utils/numberToWords';
import { GSRTC_LOGO_BASE64 } from '../utils/logoBase64';

interface DCCSummaryGujaratiProps {
  record: DCCRecord;
  onChange: (updated: DCCRecord) => void;
  isPrintMode?: boolean;
}

export const DCCSummaryGujarati: React.FC<DCCSummaryGujaratiProps> = ({
  record,
  onChange,
  isPrintMode = false,
}) => {
  const totals = calculateGujaratiTotals(record);
  const drmSlipValues = calculateDRMSlip(record);

  const handleIncomeChange = (index: number, newAmount: number) => {
    const updated = [...record.gujaratiIncomes];
    updated[index] = { ...updated[index], amount: isNaN(newAmount) ? 0 : newAmount };
    onChange({ ...record, gujaratiIncomes: updated });
  };

  const handleDeductionChange = (index: number, newAmount: number) => {
    const updated = [...record.gujaratiDeductions];
    updated[index] = { ...updated[index], amount: isNaN(newAmount) ? 0 : newAmount };
    onChange({ ...record, gujaratiDeductions: updated });
  };

  const handleOtherIncomeChange = (index: number, newAmount: number) => {
    const updated = [...record.gujaratiOtherIncomes];
    updated[index] = { ...updated[index], amount: isNaN(newAmount) ? 0 : newAmount };
    onChange({ ...record, gujaratiOtherIncomes: updated });
  };

  const handleDRMSlipChange = (field: keyof DCCRecord['drmSlip'], newAmount: number) => {
    const cleanAmount = isNaN(newAmount) ? 0 : newAmount;
    const updatedSlip = {
      ...record.drmSlip,
      [field]: cleanAmount,
    };
    const holidayDrm = Number(updatedSlip.drm) || 0;
    const newTotal =
      (updatedSlip.pos || 0) +
      holidayDrm +
      (updatedSlip.diwaliExt || 0) -
      (updatedSlip.ccRefund || 0) +
      (updatedSlip.g12 || 0) +
      (updatedSlip.ccDeposit || 0);

    updatedSlip.total = newTotal;
    onChange({ ...record, drmSlip: updatedSlip });
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border-2 border-black print-card overflow-hidden max-w-5xl mx-auto my-4 text-black font-gujarati">
      {/* Official Header matching Photo 1 */}
      <div className="border-b-2 border-black p-4 print:p-3 text-center bg-white">
        <div className="flex items-center justify-center gap-3.5">
          <img
            src={GSRTC_LOGO_BASE64}
            alt="GSRTC Logo"
            className="w-16 h-16 print:w-16 print:h-16 object-contain rounded-full border-2 border-black p-0.5 bg-white shrink-0"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = './gsrtc-logo.jpeg';
            }}
          />
          <div>
            <h2 className="text-2xl sm:text-[26px] print:text-[23px] font-black tracking-wide text-black leading-tight">
              ગુજરાત રાજ્ય માર્ગ વાહન વ્યવહાર નિગમ, સુરત વિભાગ
            </h2>
            <h3 className="text-lg sm:text-xl print:text-[17px] font-extrabold text-black mt-0.5">
              ડી.સી.સી. સમરી સુરત સીટી
            </h3>
          </div>
        </div>

        <div className="flex justify-between items-center text-sm sm:text-base print:text-[15px] font-extrabold mt-2.5 px-2">
          <span>સુરત વિભાગ • સુરત સીટી ડેપો-૨</span>
          <span>તારીખ: <span className="font-mono text-base sm:text-lg print:text-[17px] font-black underline">{record.date}</span></span>
        </div>
      </div>

      {/* Main 2-column table */}
      <div className="border-b-2 border-black flex-1 print:flex print:flex-col min-w-0 overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] print:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] print-cols-2 print:flex-1 divide-y md:divide-y-0 print:divide-y-0 md:divide-x-2 print:divide-x-2 divide-black">
          {/* LEFT: આવક (Revenue / Incomes) */}
          <div className="min-w-0 flex flex-col justify-between overflow-hidden">
            <table className="w-full table-fixed text-xs print:text-[13.5px] border-collapse flex-1 print:h-full">
              <thead>
                <tr className="border-b-2 border-black bg-slate-100 font-bold print:h-9">
                  <th className="w-7 print:w-8 border-r border-black py-1.5 print:py-1.5 px-0.5 text-center">ક્રમ</th>
                  <th className="w-14 print:w-16 border-r border-black py-1.5 print:py-1.5 px-0.5 text-center">એકા. હેડ નં.</th>
                  <th className="border-r border-black py-1.5 print:py-1.5 px-1.5 text-left">વિગત</th>
                  <th className="w-20 sm:w-24 print:w-24 py-1.5 print:py-1.5 px-1.5 text-right">રકમ રૂ.</th>
                </tr>
              </thead>
              <tbody>
                {record.gujaratiIncomes.map((item, idx) => (
                  <tr key={item.id || idx} className="border-b border-black hover:bg-amber-50/50">
                    <td className="border-r border-black py-2 print:py-[6px] px-0.5 text-center font-mono text-[11px] print:text-[12.5px] text-black">
                      {idx + 1}
                    </td>
                    <td className="border-r border-black py-2 print:py-[6px] px-0.5 text-center font-mono font-bold text-xs print:text-[13px]">
                      {item.headNo || '-'}
                    </td>
                    <td className="border-r border-black py-2 print:py-[6px] px-1.5 text-xs print:text-[13.5px] font-semibold text-black break-words">
                      {item.titleGu}
                    </td>
                    <td className="py-0 px-1.5 text-right">
                      {isPrintMode ? (
                        <span className="font-mono font-bold text-xs print:text-[14px] tabular-nums">
                          {item.amount > 0 ? formatIndianInteger(item.amount) : ''}
                        </span>
                      ) : (
                        <input
                          type="number"
                          value={item.amount === 0 ? '' : item.amount}
                          onChange={(e) => handleIncomeChange(idx, parseFloat(e.target.value))}
                          placeholder="-"
                          className="w-full text-right font-mono font-bold text-xs bg-transparent hover:bg-white focus:bg-amber-100 rounded px-1 py-1.5 focus:outline-none tabular-nums"
                        />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Total Gross Income: અ. કુલ આવક (અ) */}
            <div className="flex items-center justify-between px-3 py-2.5 print:py-2.5 print:px-3 bg-slate-200 border-t-2 border-black font-extrabold text-xs sm:text-sm print:text-[15px]">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 print:w-6 print:h-6 rounded-full bg-black text-white flex items-center justify-center text-xs print:text-sm">
                  અ
                </span>
                <span>કુલ આવક (અ)</span>
              </div>
              <span className="font-mono text-sm sm:text-base print:text-xl font-extrabold text-blue-950 tabular-nums">
                {formatIndianInteger(totals.totalA)}
              </span>
            </div>
          </div>

          {/* RIGHT: કપાત & અન્ય આવક & DRM સ્લિપ */}
          <div className="min-w-0 flex flex-col justify-between overflow-hidden">
            <div className="flex-1 flex flex-col justify-between">
              <div className="print:flex-1 print:flex print:flex-col">
                <table className="w-full table-fixed text-xs print:text-[13.5px] border-collapse print:flex-1 print:h-full">
                  <thead>
                    <tr className="border-b-2 border-black bg-slate-100 font-bold print:h-9">
                      <th className="w-7 print:w-8 border-r border-black py-1.5 print:py-1.5 px-0.5 text-center">ક્રમ</th>
                      <th className="w-14 print:w-16 border-r border-black py-1.5 print:py-1.5 px-0.5 text-center">એકા. હેડ નં.</th>
                      <th className="border-r border-black py-1.5 print:py-1.5 px-1.5 text-left">વિગત</th>
                      <th className="w-20 sm:w-24 print:w-24 py-1.5 print:py-1.5 px-2 pr-2.5 print:pr-3 text-right">રકમ રૂ.</th>
                    </tr>
                  </thead>
                  <tbody>
                    {record.gujaratiDeductions.map((item, idx) => (
                      <tr key={item.id || idx} className="border-b border-black hover:bg-amber-50/50">
                        <td className="border-r border-black py-2.5 print:py-[8.5px] px-0.5 text-center font-mono text-[11px] print:text-[12.5px] text-black">
                          {idx + 1}
                        </td>
                        <td className="border-r border-black py-2.5 print:py-[8.5px] px-0.5 text-center font-mono font-bold text-xs print:text-[13px]">
                          {item.headNo || '-'}
                        </td>
                        <td className="border-r border-black py-2.5 print:py-[8.5px] px-1.5 text-xs print:text-[13.5px] font-semibold text-black break-words">
                          {item.titleGu}
                        </td>
                        <td className="py-0 px-1.5 pr-2.5 print:pr-3 text-right">
                          {isPrintMode ? (
                            <span className="font-mono font-bold text-xs print:text-[14px] tabular-nums">
                              {item.amount > 0 ? formatIndianInteger(item.amount) : '0'}
                            </span>
                          ) : (
                            <input
                              type="number"
                              value={item.amount === 0 ? '0' : item.amount}
                              onChange={(e) => handleDeductionChange(idx, parseFloat(e.target.value))}
                              className="w-full text-right font-mono font-bold text-xs bg-transparent hover:bg-white focus:bg-amber-100 rounded px-1 py-1.5 focus:outline-none tabular-nums"
                            />
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Total Deductions: બ. કુલ કપાત (બ) */}
                <div className="flex items-center justify-between px-3 pr-3.5 py-2 print:py-2.5 print:px-3 print:pr-3.5 bg-slate-100 border-b-2 border-t border-black font-bold text-xs sm:text-sm print:text-[15px]">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 print:w-6 print:h-6 rounded-full bg-slate-700 text-white flex items-center justify-center text-xs print:text-sm">
                      બ
                    </span>
                    <span>કુલ કપાત (બ)</span>
                  </div>
                  <span className="font-mono text-sm print:text-lg font-bold text-slate-900 tabular-nums">
                    {formatIndianInteger(totals.totalB)}
                  </span>
                </div>
              </div>

              {/* અન્ય આવક (Other Income Section) */}
              <div className="border-b-2 border-black print:flex-1 print:flex print:flex-col">
                <div className="bg-slate-50 font-bold px-3 py-1.5 print:py-2 border-b border-black text-xs print:text-[13.5px]">
                  અન્ય આવક (Other Income)
                </div>
                <table className="w-full table-fixed text-xs print:text-[13.5px] print:flex-1 print:h-full">
                  <tbody>
                    {record.gujaratiOtherIncomes.map((item, idx) => (
                      <tr key={item.id || idx} className="border-b border-black">
                        <td className="w-7 print:w-8 border-r border-black py-2 print:py-[7.5px] px-0.5 text-center font-mono text-[11px] print:text-[12.5px]">
                          {idx + 1}
                        </td>
                        <td className="w-14 print:w-16 border-r border-black py-2 print:py-[7.5px] px-0.5 text-center font-mono font-bold text-xs print:text-[13px]">
                          {item.headNo || '-'}
                        </td>
                        <td className="border-r border-black py-2 print:py-[7.5px] px-1.5 text-xs print:text-[13.5px] font-semibold text-black break-words">
                          {item.titleGu}
                        </td>
                        <td className="w-20 sm:w-24 print:w-24 py-0 px-1.5 pr-2.5 print:pr-3 text-right">
                          {isPrintMode ? (
                            <span className="font-mono font-bold text-xs print:text-[14px]">{item.amount || '0'}</span>
                          ) : (
                            <input
                              type="number"
                              value={item.amount === 0 ? '0' : item.amount}
                              onChange={(e) => handleOtherIncomeChange(idx, parseFloat(e.target.value))}
                              className="w-full text-right font-mono font-bold text-xs bg-transparent hover:bg-white focus:bg-amber-100 rounded px-1 py-1 focus:outline-none"
                            />
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div className="flex items-center justify-between px-3 pr-3.5 py-2 print:py-2.5 print:px-3 print:pr-3.5 bg-slate-100 font-bold text-xs print:text-[14.5px]">
                  <div className="flex items-center gap-2">
                    <span className="w-4 h-4 print:w-5 print:h-5 rounded-full bg-slate-600 text-white flex items-center justify-center text-[10px] print:text-xs">
                      ક
                    </span>
                    <span>કુલ અન્ય આવક (ક)</span>
                  </div>
                  <span className="font-mono font-bold print:text-lg">{formatIndianInteger(totals.totalC)}</span>
                </div>
              </div>

              {/* Net Bank Remittance: બેંકમાં જમાં કરાવેલ ડી.સી.સી. તથા ડી.આર.એમ. ની આવક (અ - બ + ક) */}
              <div className="p-3 pr-3.5 print:p-3.5 print:pr-4 bg-amber-50 border-b-2 border-black">
                <div className="text-xs print:text-[13.5px] font-bold text-slate-800 mb-1">
                  બેંકમાં જમાં કરાવેલ ડી.સી.સી. તથા ડી.આર.એમ. ની આવક (અ - બ + ક)
                </div>
                <div className="text-right">
                  <span className="font-mono font-extrabold text-lg sm:text-xl print:text-2xl text-red-700 tabular-nums">
                    ₹ {formatIndianInteger(totals.netBankRemittance)}
                  </span>
                </div>
              </div>
            </div>

            {/* DRM Slip Breakdown Table (Exact match to Photo 1 bottom right sticker) */}
            <div className="p-3 pr-3.5 print:p-3.5 print:pr-4 bg-white">
              <div className="border-2 border-black rounded-lg p-2.5 print:p-3.5 max-w-xs print:max-w-[320px] w-full ml-auto bg-slate-50 shadow-xs text-xs print:text-[13.5px]">
                <div className="text-center font-bold border-b border-black pb-1 mb-1.5 text-xs print:text-[14px]">
                  ડી.આર.એમ. સ્લિપ તાળો (DRM Slip)
                </div>
                <div className="space-y-1.5 print:space-y-2 text-xs print:text-[13.5px] font-mono">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-black font-sans">P.O.S</span>
                    {isPrintMode ? (
                      <span className="font-bold">{formatIndianInteger(drmSlipValues.pos)}</span>
                    ) : (
                      <input
                        type="number"
                        value={record.drmSlip.pos}
                        onChange={(e) => handleDRMSlipChange('pos', parseFloat(e.target.value))}
                        className="w-24 text-right font-bold bg-white border border-slate-300 rounded px-1"
                      />
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-black font-sans">DRM</span>
                    {isPrintMode ? (
                      <span className="font-bold">{drmSlipValues.drm ? formatIndianInteger(drmSlipValues.drm) : ''}</span>
                    ) : (
                      <input
                        type="number"
                        value={record.drmSlip.drm ? record.drmSlip.drm : ''}
                        placeholder="રજાનું DRM"
                        title="જો અગાઉ રજા હોય અને બેંકમાં રકમ ના ભરી શકાઈ હોય તો તે DRM રકમ અહીં લખો"
                        onChange={(e) => handleDRMSlipChange('drm', parseFloat(e.target.value))}
                        className="w-24 text-right font-bold bg-white border border-slate-300 rounded px-1 placeholder:text-[10px] placeholder:text-slate-400 placeholder:font-normal focus:bg-amber-50"
                      />
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-black font-sans">G12</span>
                    {isPrintMode ? (
                      <span className="font-bold">{drmSlipValues.g12}</span>
                    ) : (
                      <input
                        type="number"
                        value={record.drmSlip.g12}
                        onChange={(e) => handleDRMSlipChange('g12', parseFloat(e.target.value))}
                        className="w-24 text-right font-bold bg-white border border-slate-300 rounded px-1"
                      />
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-black font-sans">CC DIPODIT</span>
                    {isPrintMode ? (
                      <span className="font-bold">{drmSlipValues.ccDeposit}</span>
                    ) : (
                      <input
                        type="number"
                        value={record.drmSlip.ccDeposit}
                        onChange={(e) => handleDRMSlipChange('ccDeposit', parseFloat(e.target.value))}
                        className="w-24 text-right font-bold bg-white border border-slate-300 rounded px-1"
                      />
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-black font-sans">DIWALI EXT</span>
                    {isPrintMode ? (
                      <span className="font-bold">{formatIndianInteger(drmSlipValues.diwaliExt)}</span>
                    ) : (
                      <input
                        type="number"
                        value={record.drmSlip.diwaliExt}
                        onChange={(e) => handleDRMSlipChange('diwaliExt', parseFloat(e.target.value))}
                        className="w-24 text-right font-bold bg-white border border-slate-300 rounded px-1"
                      />
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-black font-sans">CC REFUND</span>
                    {isPrintMode ? (
                      <span className="font-bold">{formatIndianInteger(drmSlipValues.ccRefund)}</span>
                    ) : (
                      <input
                        type="number"
                        value={record.drmSlip.ccRefund}
                        onChange={(e) => handleDRMSlipChange('ccRefund', parseFloat(e.target.value))}
                        className="w-24 text-right font-bold bg-white border border-slate-300 rounded px-1"
                      />
                    )}
                  </div>
                  <div className="flex justify-between items-center border-t-2 border-black pt-1 text-sm print:text-base font-extrabold text-red-700">
                    <span className="font-sans">TOTAL</span>
                    <span>{formatIndianInteger(drmSlipValues.total)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Official Signatures Bar matching Photo 1 */}
      <div className="p-4 pt-6 print:p-3 print:pt-4 grid grid-cols-1 sm:grid-cols-3 print:grid-cols-3 print-cols-3 gap-4 print:gap-2 text-center text-xs print:text-[12.5px] font-bold border-t-2 border-black bg-white">
        <div className="space-y-1">
          <div className="h-10 print:h-8"></div>
          <div className="border-t border-dashed border-black pt-1">
            <p>કેશીયર</p>
            <p className="text-[11px] print:text-[11px] text-slate-700">એસ.ટી. સુરત સીટી-ડેપો-૨</p>
          </div>
        </div>

        <div className="space-y-1">
          <div className="h-10 print:h-8"></div>
          <div className="border-t border-dashed border-black pt-1">
            <p>ટ્રાફિક સુપરવાઈઝર</p>
            <p className="text-[11px] print:text-[11px] text-slate-700">એસ.ટી. સુરત સીટી-ડેપો-૨</p>
          </div>
        </div>

        <div className="space-y-1">
          <div className="h-10 print:h-8"></div>
          <div className="border-t border-dashed border-black pt-1">
            <p>સિનિ. ડેપો મેનેજર 'એ'</p>
            <p className="text-[11px] print:text-[11px] text-slate-700">એસ.ટી. સુરત સીટી ડેપો-૨</p>
          </div>
        </div>
      </div>
    </div>
  );
};
